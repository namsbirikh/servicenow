<?php
// connexion
$ERROR="入力された情報を確認し、もう一度お試しください。";
$Email= "メールアドレス";
$Password = "パスワード";
$dok = "ログイン";
$req1 = "必須";
$req2 = '必須';
$forgot ="ログインできない場合";
$sign = "新規登録";
$checking = "情報を認証中...";
$priva = "プライバシー";
$ri8 = "All rights reserved";
$legal = "規約";
// fin connexioon
?>