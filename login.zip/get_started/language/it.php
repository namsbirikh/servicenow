<?php
// connexion
$ERROR="Alcuni dati non sono corretti. Riprova.";
$Email= "Indirizzo email";
$Password = "Password";
$dok = "Accedi";
$req1 = "L'indirizzo email è obbligatorio";
$req2 = 'La password è obbligatoria.';
$forgot ="Problemi di accesso?";
$sign = "Registrati";
$checking = "Controllo dati…";
$priva = "Privacy";
$ri8 = "Tutti i diritti riservati";
$legal = "";
// fin connexioon
?>