<?php
// signin
$ERROR = 'Please check your entries and try again.';
$Email ='Email';
$Password ='Password';
$dok ='Log In';
$req1 = 'Email address is required.';
$req2 = 'Password is required.';
$forgot ='Forgot your email or password?';
$sign = 'Sign Up';
$checking = 'Checking your info…';
$priva ='Privacy';
$ri8 = 'All rights reserved';
$legal = 'Legal';
// end signin
?>