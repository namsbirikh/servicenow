<?php
// connexion
$ERROR="Girdiğiniz bazı bilgiler hatalı.";
$Email= "E-posta";
$Password = "Şifre";
$dok = "Giriş Yapın";
$req1 = "Zorunlu";
$req2 = 'Şifre gerekli';
$forgot ="Giriş yapmakta sorun mu yaşıyorsunuz?";
$sign = "Hesap açın";
$checking = "Bilgileriniz kontrol ediliyor…";
$priva = "Gizlilik";
$ri8 = "Tüm hakları saklıdır";
$legal = "";
// fin connexioon
?>