<?php
// connexion
$ERROR="En del av uppgifterna du angett är felaktiga. Försök igen.";
$Email= "E-post";
$Password = "Lösenord";
$dok = "Logga in";
$req1 = 'Du måste ange en e-postadress.';
$req2 = 'Lösenord krävs.';
$forgot ="Har du problem med att logga in?";
$sign = "Skapa ett konto";
$checking = "Dina uppgifter kontrolleras …";
$priva = "Sekretess";
$ri8 = "Med ensamrätt";
$legal = "";
// fin connexioon
?>